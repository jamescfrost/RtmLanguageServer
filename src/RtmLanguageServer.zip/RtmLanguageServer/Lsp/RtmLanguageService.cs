using RtmLanguageServer.Analysis.Core;
using RtmLanguageServer.Analysis.Symbols;

namespace RtmLanguageServer.Lsp;

public sealed class RtmLanguageService
{
    private readonly DocumentStore _documents;

    public RtmLanguageService(DocumentStore documents) => _documents = documents;

    public IReadOnlyList<Location> GetDefinition(TextDocumentPositionParams request)
    {
        if (!_documents.TryGet(request.TextDocument.Uri, out var document) || document is null)
            return [];

        var name = document.ResolveSymbolName(request.Position);
        if (string.IsNullOrWhiteSpace(name))
            return [];

        return _documents.All
            .SelectMany(d => d.Index.FindDefinitions(name))
            .Select(s => new Location(s.Uri, s.SelectionRange))
            .DistinctBy(LocationKey)
            .OrderBy(l => l.Uri)
            .ThenBy(l => l.Range.Start.Line)
            .ThenBy(l => l.Range.Start.Character)
            .ToList();
    }

    public IReadOnlyList<Location> FindReferences(ReferenceParams request)
    {
        if (!_documents.TryGet(request.TextDocument.Uri, out var document) || document is null)
            return [];

        var name = document.ResolveSymbolName(request.Position);
        if (string.IsNullOrWhiteSpace(name))
            return [];

        var refs = new List<Location>();
        foreach (var doc in _documents.All)
            refs.AddRange(doc.Index.FindReferences(name, request.Context.IncludeDeclaration));

        return refs
            .DistinctBy(LocationKey)
            .OrderBy(l => l.Uri)
            .ThenBy(l => l.Range.Start.Line)
            .ThenBy(l => l.Range.Start.Character)
            .ToList();
    }

    public Hover? Hover(TextDocumentPositionParams request)
    {
        if (!_documents.TryGet(request.TextDocument.Uri, out var document) || document is null)
            return null;

        var symbol = document.ResolveSymbolAt(request.Position, _documents.All);
        if (symbol is null)
            return null;

        return new Hover
        {
            Contents = new MarkupContent
            {
                Kind = "markdown",
                Value = BuildHoverMarkdown(symbol)
            },
            Range = symbol.SelectionRange
        };
    }

    private static string BuildHoverMarkdown(RtmSymbol symbol)
    {
        var lines = new List<string>
        {
            $"**{ToTitle(symbol.Label)}** `{symbol.Name}`"
        };

        var detail = symbol.GetMarkdown();
        if (!string.IsNullOrWhiteSpace(detail))
            lines.Add(detail);

        if (symbol is not OverlaySymbol)
            lines.Add($"Overlay: `{symbol.Name}`");

        if (symbol is OverlaySymbol overlayWithChildren && overlayWithChildren.Children.Count > 0)
        {
            var childSummary = overlayWithChildren.Children
                .GroupBy(c => c.Label)
                .OrderBy(g => g.Key)
                .Select(g => $"{g.Count()} {g.Key}");

            lines.Add($"Children: {string.Join(", ", childSummary)}");
        }

        lines.Add($"Defined in `{DisplayUri(symbol.Uri)}`");

        return string.Join("\n\n", lines);
    }

    private static string ToTitle(string value)
    {
        if (string.IsNullOrWhiteSpace(value))
            return "Symbol";

        return char.ToUpperInvariant(value[0]) + value[1..];
    }

    private static string LocationKey(Location l) =>
        $"{l.Uri}:{l.Range.Start.Line}:{l.Range.Start.Character}:{l.Range.End.Line}:{l.Range.End.Character}";

    private static string DisplayUri(string uri)
    {
        if (Uri.TryCreate(uri, UriKind.Absolute, out var parsed) && parsed.IsFile)
            return Path.GetFileName(parsed.LocalPath);
        return uri;
    }
}